package com.assignment.EmailCounter.controller;

import com.assignment.EmailCounter.service.EmailCounterService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/email")
public class EmailCounterController {

    private final EmailCounterService emailCounterService;

    @GetMapping("/count")
    public int countEmails(@RequestParam String sender) throws Exception {
        return emailCounterService.countEmailsFromSender(sender);
    }

}
