package com.assignment.EmailCounter.service.impl;

import com.assignment.EmailCounter.service.EmailCounterService;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.google.api.services.gmail.model.Message;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;


@Service
@RequiredArgsConstructor
public class EmailCounterServiceImpl implements EmailCounterService {

    private final Gmail gmail;

    public int countEmailsFromSender(String sender) throws IOException {
        String query = "from:" + sender;

        ListMessagesResponse response = gmail.users()
                .messages()
                .list("prayansh.agrawal.5@gmail.com")
                .setQ(query)
                .execute();

        List<Message> messages = response.getMessages();

        return messages == null ? 0 : messages.size();
    }
}
