package com.assignment.EmailCounter.service;

import java.io.IOException;

public interface EmailCounterService {
    int countEmailsFromSender(String sender) throws IOException;
}
